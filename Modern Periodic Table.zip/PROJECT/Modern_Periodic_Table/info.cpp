#include "info.h"
#include "ui_info.h"
#include "mainwindow.h"
#include <QString>
#include <QSql>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>

Info::Info(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Info)
{
    ui->setupUi(this);


    QFont font;
    font.setPixelSize(12);
    Info::setFont(font);
}

Info::~Info()
{
    delete ui;
}

void connectDB()
{
    // Setup the database connection.
    // *** TODO: The database name must be changed for the final relese.
    QSqlDatabase mydb = QSqlDatabase::addDatabase("QSQLITE","database_connect");
    mydb.setDatabaseName("database.db");

    if(!mydb.open())
    {
        mydb.setDatabaseName("database.db");
    }
    else
    {
        mydb.close();
    }
}

void Info::receiveName(QString elem)
{
    // Get the element name from the slot (QString elem).
   ui->lbl_name->setText(elem);
    this->setWindowTitle("Details about element " + elem);

    connectDB();

      QSqlQuery qry(QSqlDatabase::database("database_connect"));

        // Query the database for atomic information on the selected element. Provided by (elem).
        if(qry.exec("SELECT * FROM Atom WHERE Name='" + elem + "'"))
        {
            while(qry.next())
            {
                // Load the electron shell image form the database.
                QByteArray outByteArray = qry.value(6).toByteArray();
                QPixmap outPixmap = QPixmap();
                outPixmap.loadFromData(outByteArray);

                ui->lbl_atNumber->setText(qry.value(4).toString());
                ui->lbl_Symbol->setText(qry.value(2).toString());
                ui->lbl_Weight->setText(qry.value(3).toString());
                ui->lbl_ec->setText(qry.value(5).toString());
                ui->lbl_pic->setPixmap(outPixmap);
            }
        }

        else
        {
            // On fail. Give us a reasonable error.
            QMessageBox::critical(this, "Periodic Table of Elements Database Error:", qry.lastError().text());
            QSqlDatabase::removeDatabase("database_connect");
            return;
        }
        // Query the database for element information on the selected element provided by (s).
        if(qry.exec("SELECT * FROM elements WHERE Name='" + elem + "'"))
        {
            while(qry.next())
            {
                ui->lbl_isotopes->setText(qry.value(2).toString());
                ui->lbl_isotopes2->setText(qry.value(3).toString());
                ui->lbl_facts->setText(qry.value(4).toString());
                QByteArray outByteArray = qry.value(5).toByteArray();
                QPixmap outPixmap = QPixmap();
                outPixmap.loadFromData(outByteArray);
                ui->lbl_prop->setPixmap(outPixmap);
                ui->lbl_prop->setScaledContents(true);
            }
        }
        else
        {
            // On fail. Give us a reasonable error.
            QMessageBox::critical(this, "Periodic Table of Elements Database Error:", qry.lastError().text());
            QSqlDatabase::removeDatabase("database_connect");
            return;
        }
        // Remove the database connection name.
        QSqlDatabase::removeDatabase("database_connect");
}

void Info::on_closeButton_clicked()
{
    this->close();
}
