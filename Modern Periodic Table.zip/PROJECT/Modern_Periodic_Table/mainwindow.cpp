#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "info.h"
#include <QRect>
#include <QApplication>
#include <QDesktopWidget>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QFont font;
    font.setPixelSize(12);
    MainWindow::setFont(font);
     this->setWindowTitle("Periodic Table of Elements");

   //Window screen Locator
    QRect screenGeometry = QApplication::desktop()->screenGeometry();
    int x = (screenGeometry.width() - MainWindow::width()) /2;
    int y = (screenGeometry.height() - MainWindow::height()) /2;
    MainWindow::move(x, y);
    MainWindow::show();
}

MainWindow::~MainWindow()
{
    delete ui;
}
//FindElement(QString);

void MainWindow::FindElement(QString elem)
{

    info = new Info(this);
    //Info info;
    info->setModal(true);
    info->show();

    // Connector for the elemDialog to receive the element name.
    connect(this, SIGNAL(sendName(QString)), info, SLOT(receiveName(QString)));

    // Emitter.
    emit sendName(elem);
}

void MainWindow::on_pushButton_Hydrogen_clicked()
{
    QString elem;
    elem= "Hydrogen";

    FindElement(elem);
}

void MainWindow::on_pushButton_Helium_clicked()
{
    QString elem;
    elem= "Helium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Lithium_clicked()
{
    QString elem;
    elem= "Lithium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Berylium_clicked()
{
    QString elem;
    elem= "Beryllium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Boron_clicked()
{
    QString elem;
    elem= "Boron";

    FindElement(elem);
}

void MainWindow::on_pushButton_Carbon_clicked()
{
    QString elem;
    elem= "Carbon";

    FindElement(elem);
}

void MainWindow::on_pushButton_Nitrogen_clicked()
{
    QString elem;
    elem= "Nitrogen";

    FindElement(elem);
}

void MainWindow::on_pushButton_Oxygen_clicked()
{
    QString elem;
    elem= "Oxygen";

    FindElement(elem);
}

void MainWindow::on_pushButton_Fluorine_clicked()
{
    QString elem;
    elem= "Fluorine";

    FindElement(elem);
}

void MainWindow::on_pushButton_Neon_clicked()
{
    QString elem;
    elem= "Neon";

    FindElement(elem);
}

void MainWindow::on_pushButton_Sodium_clicked()
{
    QString elem;
    elem= "Sodium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Magnesium_clicked()
{
    QString elem;
    elem= "Magnesium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Al_13_clicked()
{
    QString elem;
    elem= "Aluminum";

    FindElement(elem);
}

void MainWindow::on_pushButton_Silicon_clicked()
{
    QString elem;
    elem= "Silicon";

    FindElement(elem);
}

void MainWindow::on_pushButton_Phosphorus_clicked()
{
    QString elem;
    elem= "Phosphorus";

    FindElement(elem);
}

void MainWindow::on_pushButton_Sulphur_clicked()
{
    QString elem;
    elem= "Sulfur";

    FindElement(elem);
}

void MainWindow::on_pushButton_Chlorine_clicked()
{
    QString elem;
    elem= "Chlorine";

    FindElement(elem);
}

void MainWindow::on_pushButton_Argon_clicked()
{
    QString elem;
    elem= "Argon";

    FindElement(elem);
}

void MainWindow::on_pushButton_Potassium_clicked()
{
    QString elem;
    elem= "Potassium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Calcium_clicked()
{
    QString elem;
    elem= "Calcium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Scandium_clicked()
{
    QString elem;
    elem= "Scandium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Titanium_clicked()
{
    QString elem;
    elem= "Titanium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Vanadium_clicked()
{
    QString elem;
    elem= "Vanadium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Chromium_clicked()
{
    QString elem;
    elem= "Chromium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Magenesse_clicked()
{
    QString elem;
    elem= "Manganese";

    FindElement(elem);
}

void MainWindow::on_pushButton_Iron_clicked()
{
    QString elem;
    elem= "Iron";

    FindElement(elem);
}

void MainWindow::on_pushButton_Cobalt_clicked()
{
    QString elem;
    elem= "Cobalt";

    FindElement(elem);
}

void MainWindow::on_pushButton_Nickel_clicked()
{
    QString elem;
    elem= "Nickel";

    FindElement(elem);
}

void MainWindow::on_pushButton_Copper_clicked()
{
    QString elem;
    elem= "Copper";

    FindElement(elem);
}

void MainWindow::on_pushButton_Zinc_clicked()
{
    QString elem;
    elem= "Zinc";

    FindElement(elem);
}

void MainWindow::on_pushButton_Gallium_clicked()
{
    QString elem;
    elem= "Gallium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Germanium_clicked()
{
    QString elem;
    elem= "Germanium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Arsenic_clicked()
{
    QString elem;
    elem= "Arsenic";

    FindElement(elem);
}

void MainWindow::on_pushButton_Selenium_clicked()
{
    QString elem;
    elem= "Selenium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Bromine_clicked()
{
    QString elem;
    elem= "Bromine";

    FindElement(elem);
}

void MainWindow::on_pushButton_Krypton_clicked()
{
    QString elem;
    elem= "Krypton";

    FindElement(elem);
}

void MainWindow::on_pushButton_Rubidium_clicked()
{
    QString elem;
    elem= "Rubidium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Strontium_clicked()
{
    QString elem;
    elem= "Strontium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Yittium_clicked()
{
    QString elem;
    elem= "Yttrium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Niobium_clicked()
{
    QString elem;
    elem= "Niobium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Technetium_clicked()
{
    QString elem;
    elem= "Technetium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Ruthenium_clicked()
{
    QString elem;
    elem= "Ruthenium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Rhodium_clicked()
{
    QString elem;
    elem= "Rhodium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Palladium_clicked()
{
    QString elem;
    elem= "Palladium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Silver_clicked()
{
    QString elem;
    elem= "Silver";

    FindElement(elem);
}

void MainWindow::on_pushButton_Cadmium_clicked()
{
    QString elem;
    elem= "Cadmium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Indium_clicked()
{
    QString elem;
    elem= "Indium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Tin_clicked()
{
    QString elem;
    elem= "Tin";

    FindElement(elem);
}

void MainWindow::on_pushButton_Antimony_clicked()
{
    QString elem;
    elem= "Antimony";

    FindElement(elem);
}

void MainWindow::on_pushButton_Tellurium_clicked()
{
    QString elem;
    elem= "Tellurium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Iodine_clicked()
{
    QString elem;
    elem= "Iodine";

    FindElement(elem);
}

void MainWindow::on_pushButton_Xenon_clicked()
{
    QString elem;
    elem= "Xenon";

    FindElement(elem);
}

void MainWindow::on_pushButton_Caesium_clicked()
{
    QString elem;
    elem= "Cesium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Barium_clicked()
{
    QString elem;
    elem= "Barium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Lanthanum_clicked()
{
    QString elem;
    elem= "Lanthanum";

    FindElement(elem);
}

void MainWindow::on_pushButton_Cerium_clicked()
{
    QString elem;
    elem= "Cerium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Praseodymium_clicked()
{
    QString elem;
    elem= "Praseodymium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Neodymium_clicked()
{
    QString elem;
    elem= "Neodymium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Promethium_clicked()
{
    QString elem;
    elem= "Promethium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Samarium_clicked()
{
    QString elem;
    elem= "Samarium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Europium_clicked()
{
    QString elem;
    elem= "Europium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Gadolinium_clicked()
{
    QString elem;
    elem= "Gadolinium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Terbium_clicked()
{
    QString elem;
    elem= "Terbium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Dysprosium_clicked()
{
    QString elem;
    elem= "Dysprosium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Holmium_clicked()
{
    QString elem;
    elem= "Holmium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Erbium_clicked()
{
    QString elem;
    elem= "Erbium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Thulium_clicked()
{
    QString elem;
    elem= "Thulium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Ytterbium_clicked()
{
    QString elem;
    elem= "Ytterbium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Lutetium_clicked()
{
    QString elem;
    elem= "Lutetium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Hafnium_clicked()
{
    QString elem;
    elem= "Hafnium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Tantalum_clicked()
{
    QString elem;
    elem= "Tantalum";

    FindElement(elem);
}

void MainWindow::on_pushButton_Tungsten_clicked()
{
    QString elem;
    elem= "Tungsten";

    FindElement(elem);
}

void MainWindow::on_pushButton_Rhenium_clicked()
{
    QString elem;
    elem= "Rhenium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Osmium_clicked()
{
    QString elem;
    elem= "Osmium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Iridium_clicked()
{
    QString elem;
    elem= "Iridium";

    FindElement(elem);
}

void MainWindow::on_pushButton_platinum_clicked()
{
    QString elem;
    elem= "Platinum";

    FindElement(elem);
}

void MainWindow::on_pushButton_Gold_clicked()
{
    QString elem;
    elem= "Gold";

    FindElement(elem);
}

void MainWindow::on_pushButton_Mercury_clicked()
{
    QString elem;
    elem= "Mercury";

    FindElement(elem);
}

void MainWindow::on_pushButton_Thallium_clicked()
{
    QString elem;
    elem= "Thallium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Lead_clicked()
{
    QString elem;
    elem= "Lead";

    FindElement(elem);
}

void MainWindow::on_pushButton_Bismuth_clicked()
{
    QString elem;
    elem= "Bismuth";

    FindElement(elem);
}

void MainWindow::on_pushButton_Polonium_clicked()
{
    QString elem;
    elem= "Polonium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Astatine_clicked()
{
    QString elem;
    elem= "Astatine";

    FindElement(elem);
}

void MainWindow::on_pushButton_Radon_clicked()
{
    QString elem;
    elem= "Radon";

    FindElement(elem);
}

void MainWindow::on_pushButton_Francium_clicked()
{
    QString elem;
    elem= "Francium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Radium_clicked()
{
    QString elem;
    elem= "Radium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Actinium_clicked()
{
    QString elem;
    elem= "Actinium";

    FindElement(elem);
}
void MainWindow::on_pushButton_Thorium_clicked()
{
    QString elem;
    elem= "Thorium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Protactinium_clicked()
{
    QString elem;
    elem= "Protactinium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Uranium_clicked()
{
    QString elem;
    elem= "Uranium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Neptunium_clicked()
{
    QString elem;
    elem= "Neptunium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Plutonium_clicked()
{
    QString elem;
    elem= "Plutonium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Americium_clicked()
{
    QString elem;
    elem= "Americium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Curium_clicked()
{
    QString elem;
    elem= "Curium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Berkelium_clicked()
{
    QString elem;
    elem= "Berkelium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Californium_clicked()
{
    QString elem;
    elem= "Californium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Einsteinium_clicked()
{
    QString elem;
    elem= "Einsteinium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Fermium_clicked()
{
    QString elem;
    elem= "Fermium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Mendevlevium_clicked()
{
    QString elem;
    elem= "Mendelevium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Nobelium_clicked()
{
    QString elem;
    elem= "Nobelium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Lawrencium_clicked()
{
    QString elem;
    elem= "Lawrencium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Rutherfordium_clicked()
{
    QString elem;
    elem= "Rutherfordium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Dubnium_clicked()
{
    QString elem;
    elem= "Dubnium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Seaborgium_clicked()
{
    QString elem;
    elem= "Seaborgium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Bohrium_clicked()
{
    QString elem;
    elem= "Bohrium";

    FindElement(elem);
}

void MainWindow::on_pushButton_hassium_clicked()
{
    QString elem;
    elem= "Hassium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Meitnerium_clicked()
{
    QString elem;
    elem= "Meitnerium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Darmstadium_clicked()
{
    QString elem;
    elem= "Darmstadtium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Roentgenium_clicked()
{
    QString elem;
    elem= "Roentgenium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Coprenicium_clicked()
{
    QString elem;
    elem= "Copernicium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Nihomium_clicked()
{
    QString elem;
    elem= "Nihonium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Flerovium_clicked()
{
    QString elem;
    elem= "Flerovium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Moscovium_clicked()
{
    QString elem;
    elem= "Moscovium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Livermorium_clicked()
{
    QString elem;
    elem= "Livermorium";

    FindElement(elem);
}

void MainWindow::on_pushButton_Tennessine_clicked()
{
    QString elem;
    elem= "Tennessine";

    FindElement(elem);
}

void MainWindow::on_pushButton_Oganesson_clicked()
{
    QString elem;
    elem= "Oganesson";

    FindElement(elem);
}

void MainWindow::on_pushButton_Molybdenum_clicked()
{
    QString elem;
    elem= "Molybdenum";

    FindElement(elem);
}


void MainWindow::on_pushButton_Zicronium_clicked()
{
    QString elem;
    elem= "Zirconium";

    FindElement(elem);
}


