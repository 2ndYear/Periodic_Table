#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ui_mainwindow.h"
#include "info.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

   void  FindElement(QString elem);

private slots:
    //void on_pushButton_10_clicked();

    //void on_pushButton_104_clicked();

   // void on_pushButton_119_clicked();

    //void on_pushButton_9_clicked();

    void on_pushButton_Hydrogen_clicked();

    void on_pushButton_Helium_clicked();

    void on_pushButton_Lithium_clicked();

    void on_pushButton_Berylium_clicked();

    void on_pushButton_Boron_clicked();

    void on_pushButton_Carbon_clicked();

    void on_pushButton_Nitrogen_clicked();

    void on_pushButton_Oxygen_clicked();

    void on_pushButton_Fluorine_clicked();

    void on_pushButton_Neon_clicked();

    void on_pushButton_Sodium_clicked();

    void on_pushButton_Magnesium_clicked();

    void on_pushButton_Al_13_clicked();

    void on_pushButton_Silicon_clicked();

    void on_pushButton_Phosphorus_clicked();

    void on_pushButton_Sulphur_clicked();

    void on_pushButton_Chlorine_clicked();

    void on_pushButton_Argon_clicked();

    void on_pushButton_Potassium_clicked();

    void on_pushButton_Calcium_clicked();

    void on_pushButton_Scandium_clicked();

    void on_pushButton_Titanium_clicked();

    void on_pushButton_Vanadium_clicked();

    void on_pushButton_Magenesse_clicked();

    void on_pushButton_Iron_clicked();

    void on_pushButton_Cobalt_clicked();

    void on_pushButton_Nickel_clicked();

    void on_pushButton_Copper_clicked();

    void on_pushButton_Zinc_clicked();

    void on_pushButton_Gallium_clicked();

    void on_pushButton_Germanium_clicked();

    void on_pushButton_Arsenic_clicked();

    void on_pushButton_Selenium_clicked();

    void on_pushButton_Chromium_clicked();

    void on_pushButton_Bromine_clicked();

    void on_pushButton_Krypton_clicked();

    void on_pushButton_Rubidium_clicked();

    void on_pushButton_Strontium_clicked();

    void on_pushButton_Yittium_clicked();

    void on_pushButton_Zicronium_clicked();

    void on_pushButton_Niobium_clicked();

    //void on_pushButton_Molybendium_clicked();

    void on_pushButton_Molybdenum_clicked();

    void on_pushButton_Technetium_clicked();

    void on_pushButton_Ruthenium_clicked();

    void on_pushButton_Rhodium_clicked();

    void on_pushButton_Palladium_clicked();

    void on_pushButton_Silver_clicked();

    void on_pushButton_Cadmium_clicked();

    void on_pushButton_Indium_clicked();

    void on_pushButton_Tin_clicked();

    void on_pushButton_Antimony_clicked();

    void on_pushButton_Tellurium_clicked();

    void on_pushButton_Iodine_clicked();

    void on_pushButton_Xenon_clicked();

    void on_pushButton_Caesium_clicked();

    void on_pushButton_Barium_clicked();

    void on_pushButton_Lanthanum_clicked();

    void on_pushButton_Cerium_clicked();

    void on_pushButton_Praseodymium_clicked();

    void on_pushButton_Neodymium_clicked();

    void on_pushButton_Promethium_clicked();

    void on_pushButton_Samarium_clicked();

    void on_pushButton_Europium_clicked();

    void on_pushButton_Gadolinium_clicked();

    void on_pushButton_Terbium_clicked();

    void on_pushButton_Dysprosium_clicked();

    void on_pushButton_Holmium_clicked();

    void on_pushButton_Erbium_clicked();

    void on_pushButton_Thulium_clicked();

    void on_pushButton_Ytterbium_clicked();

    void on_pushButton_Lutetium_clicked();

    void on_pushButton_Actinium_clicked();

    void on_pushButton_Hafnium_clicked();

    void on_pushButton_Tantalum_clicked();

    void on_pushButton_Tungsten_clicked();

    void on_pushButton_Rhenium_clicked();

    void on_pushButton_Osmium_clicked();

    void on_pushButton_Iridium_clicked();

    void on_pushButton_platinum_clicked();

    void on_pushButton_Gold_clicked();

    void on_pushButton_Mercury_clicked();

    void on_pushButton_Thallium_clicked();

    void on_pushButton_Lead_clicked();

    void on_pushButton_Bismuth_clicked();

    void on_pushButton_Polonium_clicked();

    void on_pushButton_Astatine_clicked();

    void on_pushButton_Radon_clicked();

    void on_pushButton_Francium_clicked();

    void on_pushButton_Radium_clicked();

    void on_pushButton_Thorium_clicked();

    void on_pushButton_Protactinium_clicked();

    void on_pushButton_Uranium_clicked();

    void on_pushButton_Neptunium_clicked();

    void on_pushButton_Plutonium_clicked();

    void on_pushButton_Americium_clicked();

    void on_pushButton_Curium_clicked();

    void on_pushButton_Berkelium_clicked();

    void on_pushButton_Californium_clicked();

    void on_pushButton_Einsteinium_clicked();

    void on_pushButton_Fermium_clicked();

    void on_pushButton_Mendevlevium_clicked();

    void on_pushButton_Nobelium_clicked();

    void on_pushButton_Lawrencium_clicked();

    void on_pushButton_Rutherfordium_clicked();

    void on_pushButton_Dubnium_clicked();

    void on_pushButton_Seaborgium_clicked();

    void on_pushButton_Bohrium_clicked();

    void on_pushButton_hassium_clicked();

    void on_pushButton_Meitnerium_clicked();

    void on_pushButton_Darmstadium_clicked();

    void on_pushButton_Roentgenium_clicked();

    void on_pushButton_Coprenicium_clicked();

    void on_pushButton_Nihomium_clicked();

    void on_pushButton_Flerovium_clicked();

    void on_pushButton_Moscovium_clicked();

    void on_pushButton_Livermorium_clicked();

    void on_pushButton_Tennessine_clicked();

    void on_pushButton_Oganesson_clicked();

   // void on_pushButton_Molybednum_clicked();

    //void on_pushButton_53_clicked();

   // void on_pushButton_Zirconium_clicked();

    //void on_pushButton_2_clicked();
signals:
    void sendName(QString);

private:
    Ui::MainWindow *ui;
    Info *info;

};

#endif // MAINWINDOW_H
