/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Modern_Periodic_Table/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[121];
    char stringdata0[3654];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 8), // "sendName"
QT_MOC_LITERAL(2, 20, 0), // ""
QT_MOC_LITERAL(3, 21, 30), // "on_pushButton_Hydrogen_clicked"
QT_MOC_LITERAL(4, 52, 28), // "on_pushButton_Helium_clicked"
QT_MOC_LITERAL(5, 81, 29), // "on_pushButton_Lithium_clicked"
QT_MOC_LITERAL(6, 111, 30), // "on_pushButton_Berylium_clicked"
QT_MOC_LITERAL(7, 142, 27), // "on_pushButton_Boron_clicked"
QT_MOC_LITERAL(8, 170, 28), // "on_pushButton_Carbon_clicked"
QT_MOC_LITERAL(9, 199, 30), // "on_pushButton_Nitrogen_clicked"
QT_MOC_LITERAL(10, 230, 28), // "on_pushButton_Oxygen_clicked"
QT_MOC_LITERAL(11, 259, 30), // "on_pushButton_Fluorine_clicked"
QT_MOC_LITERAL(12, 290, 26), // "on_pushButton_Neon_clicked"
QT_MOC_LITERAL(13, 317, 28), // "on_pushButton_Sodium_clicked"
QT_MOC_LITERAL(14, 346, 31), // "on_pushButton_Magnesium_clicked"
QT_MOC_LITERAL(15, 378, 27), // "on_pushButton_Al_13_clicked"
QT_MOC_LITERAL(16, 406, 29), // "on_pushButton_Silicon_clicked"
QT_MOC_LITERAL(17, 436, 32), // "on_pushButton_Phosphorus_clicked"
QT_MOC_LITERAL(18, 469, 29), // "on_pushButton_Sulphur_clicked"
QT_MOC_LITERAL(19, 499, 30), // "on_pushButton_Chlorine_clicked"
QT_MOC_LITERAL(20, 530, 27), // "on_pushButton_Argon_clicked"
QT_MOC_LITERAL(21, 558, 31), // "on_pushButton_Potassium_clicked"
QT_MOC_LITERAL(22, 590, 29), // "on_pushButton_Calcium_clicked"
QT_MOC_LITERAL(23, 620, 30), // "on_pushButton_Scandium_clicked"
QT_MOC_LITERAL(24, 651, 30), // "on_pushButton_Titanium_clicked"
QT_MOC_LITERAL(25, 682, 30), // "on_pushButton_Vanadium_clicked"
QT_MOC_LITERAL(26, 713, 31), // "on_pushButton_Magenesse_clicked"
QT_MOC_LITERAL(27, 745, 26), // "on_pushButton_Iron_clicked"
QT_MOC_LITERAL(28, 772, 28), // "on_pushButton_Cobalt_clicked"
QT_MOC_LITERAL(29, 801, 28), // "on_pushButton_Nickel_clicked"
QT_MOC_LITERAL(30, 830, 28), // "on_pushButton_Copper_clicked"
QT_MOC_LITERAL(31, 859, 26), // "on_pushButton_Zinc_clicked"
QT_MOC_LITERAL(32, 886, 29), // "on_pushButton_Gallium_clicked"
QT_MOC_LITERAL(33, 916, 31), // "on_pushButton_Germanium_clicked"
QT_MOC_LITERAL(34, 948, 29), // "on_pushButton_Arsenic_clicked"
QT_MOC_LITERAL(35, 978, 30), // "on_pushButton_Selenium_clicked"
QT_MOC_LITERAL(36, 1009, 30), // "on_pushButton_Chromium_clicked"
QT_MOC_LITERAL(37, 1040, 29), // "on_pushButton_Bromine_clicked"
QT_MOC_LITERAL(38, 1070, 29), // "on_pushButton_Krypton_clicked"
QT_MOC_LITERAL(39, 1100, 30), // "on_pushButton_Rubidium_clicked"
QT_MOC_LITERAL(40, 1131, 31), // "on_pushButton_Strontium_clicked"
QT_MOC_LITERAL(41, 1163, 29), // "on_pushButton_Yittium_clicked"
QT_MOC_LITERAL(42, 1193, 31), // "on_pushButton_Zicronium_clicked"
QT_MOC_LITERAL(43, 1225, 29), // "on_pushButton_Niobium_clicked"
QT_MOC_LITERAL(44, 1255, 32), // "on_pushButton_Molybdenum_clicked"
QT_MOC_LITERAL(45, 1288, 32), // "on_pushButton_Technetium_clicked"
QT_MOC_LITERAL(46, 1321, 31), // "on_pushButton_Ruthenium_clicked"
QT_MOC_LITERAL(47, 1353, 29), // "on_pushButton_Rhodium_clicked"
QT_MOC_LITERAL(48, 1383, 31), // "on_pushButton_Palladium_clicked"
QT_MOC_LITERAL(49, 1415, 28), // "on_pushButton_Silver_clicked"
QT_MOC_LITERAL(50, 1444, 29), // "on_pushButton_Cadmium_clicked"
QT_MOC_LITERAL(51, 1474, 28), // "on_pushButton_Indium_clicked"
QT_MOC_LITERAL(52, 1503, 25), // "on_pushButton_Tin_clicked"
QT_MOC_LITERAL(53, 1529, 30), // "on_pushButton_Antimony_clicked"
QT_MOC_LITERAL(54, 1560, 31), // "on_pushButton_Tellurium_clicked"
QT_MOC_LITERAL(55, 1592, 28), // "on_pushButton_Iodine_clicked"
QT_MOC_LITERAL(56, 1621, 27), // "on_pushButton_Xenon_clicked"
QT_MOC_LITERAL(57, 1649, 29), // "on_pushButton_Caesium_clicked"
QT_MOC_LITERAL(58, 1679, 28), // "on_pushButton_Barium_clicked"
QT_MOC_LITERAL(59, 1708, 31), // "on_pushButton_Lanthanum_clicked"
QT_MOC_LITERAL(60, 1740, 28), // "on_pushButton_Cerium_clicked"
QT_MOC_LITERAL(61, 1769, 34), // "on_pushButton_Praseodymium_cl..."
QT_MOC_LITERAL(62, 1804, 31), // "on_pushButton_Neodymium_clicked"
QT_MOC_LITERAL(63, 1836, 32), // "on_pushButton_Promethium_clicked"
QT_MOC_LITERAL(64, 1869, 30), // "on_pushButton_Samarium_clicked"
QT_MOC_LITERAL(65, 1900, 30), // "on_pushButton_Europium_clicked"
QT_MOC_LITERAL(66, 1931, 32), // "on_pushButton_Gadolinium_clicked"
QT_MOC_LITERAL(67, 1964, 29), // "on_pushButton_Terbium_clicked"
QT_MOC_LITERAL(68, 1994, 32), // "on_pushButton_Dysprosium_clicked"
QT_MOC_LITERAL(69, 2027, 29), // "on_pushButton_Holmium_clicked"
QT_MOC_LITERAL(70, 2057, 28), // "on_pushButton_Erbium_clicked"
QT_MOC_LITERAL(71, 2086, 29), // "on_pushButton_Thulium_clicked"
QT_MOC_LITERAL(72, 2116, 31), // "on_pushButton_Ytterbium_clicked"
QT_MOC_LITERAL(73, 2148, 30), // "on_pushButton_Lutetium_clicked"
QT_MOC_LITERAL(74, 2179, 30), // "on_pushButton_Actinium_clicked"
QT_MOC_LITERAL(75, 2210, 29), // "on_pushButton_Hafnium_clicked"
QT_MOC_LITERAL(76, 2240, 30), // "on_pushButton_Tantalum_clicked"
QT_MOC_LITERAL(77, 2271, 30), // "on_pushButton_Tungsten_clicked"
QT_MOC_LITERAL(78, 2302, 29), // "on_pushButton_Rhenium_clicked"
QT_MOC_LITERAL(79, 2332, 28), // "on_pushButton_Osmium_clicked"
QT_MOC_LITERAL(80, 2361, 29), // "on_pushButton_Iridium_clicked"
QT_MOC_LITERAL(81, 2391, 30), // "on_pushButton_platinum_clicked"
QT_MOC_LITERAL(82, 2422, 26), // "on_pushButton_Gold_clicked"
QT_MOC_LITERAL(83, 2449, 29), // "on_pushButton_Mercury_clicked"
QT_MOC_LITERAL(84, 2479, 30), // "on_pushButton_Thallium_clicked"
QT_MOC_LITERAL(85, 2510, 26), // "on_pushButton_Lead_clicked"
QT_MOC_LITERAL(86, 2537, 29), // "on_pushButton_Bismuth_clicked"
QT_MOC_LITERAL(87, 2567, 30), // "on_pushButton_Polonium_clicked"
QT_MOC_LITERAL(88, 2598, 30), // "on_pushButton_Astatine_clicked"
QT_MOC_LITERAL(89, 2629, 27), // "on_pushButton_Radon_clicked"
QT_MOC_LITERAL(90, 2657, 30), // "on_pushButton_Francium_clicked"
QT_MOC_LITERAL(91, 2688, 28), // "on_pushButton_Radium_clicked"
QT_MOC_LITERAL(92, 2717, 29), // "on_pushButton_Thorium_clicked"
QT_MOC_LITERAL(93, 2747, 34), // "on_pushButton_Protactinium_cl..."
QT_MOC_LITERAL(94, 2782, 29), // "on_pushButton_Uranium_clicked"
QT_MOC_LITERAL(95, 2812, 31), // "on_pushButton_Neptunium_clicked"
QT_MOC_LITERAL(96, 2844, 31), // "on_pushButton_Plutonium_clicked"
QT_MOC_LITERAL(97, 2876, 31), // "on_pushButton_Americium_clicked"
QT_MOC_LITERAL(98, 2908, 28), // "on_pushButton_Curium_clicked"
QT_MOC_LITERAL(99, 2937, 31), // "on_pushButton_Berkelium_clicked"
QT_MOC_LITERAL(100, 2969, 33), // "on_pushButton_Californium_cli..."
QT_MOC_LITERAL(101, 3003, 33), // "on_pushButton_Einsteinium_cli..."
QT_MOC_LITERAL(102, 3037, 29), // "on_pushButton_Fermium_clicked"
QT_MOC_LITERAL(103, 3067, 34), // "on_pushButton_Mendevlevium_cl..."
QT_MOC_LITERAL(104, 3102, 30), // "on_pushButton_Nobelium_clicked"
QT_MOC_LITERAL(105, 3133, 32), // "on_pushButton_Lawrencium_clicked"
QT_MOC_LITERAL(106, 3166, 35), // "on_pushButton_Rutherfordium_c..."
QT_MOC_LITERAL(107, 3202, 29), // "on_pushButton_Dubnium_clicked"
QT_MOC_LITERAL(108, 3232, 32), // "on_pushButton_Seaborgium_clicked"
QT_MOC_LITERAL(109, 3265, 29), // "on_pushButton_Bohrium_clicked"
QT_MOC_LITERAL(110, 3295, 29), // "on_pushButton_hassium_clicked"
QT_MOC_LITERAL(111, 3325, 32), // "on_pushButton_Meitnerium_clicked"
QT_MOC_LITERAL(112, 3358, 33), // "on_pushButton_Darmstadium_cli..."
QT_MOC_LITERAL(113, 3392, 33), // "on_pushButton_Roentgenium_cli..."
QT_MOC_LITERAL(114, 3426, 33), // "on_pushButton_Coprenicium_cli..."
QT_MOC_LITERAL(115, 3460, 30), // "on_pushButton_Nihomium_clicked"
QT_MOC_LITERAL(116, 3491, 31), // "on_pushButton_Flerovium_clicked"
QT_MOC_LITERAL(117, 3523, 31), // "on_pushButton_Moscovium_clicked"
QT_MOC_LITERAL(118, 3555, 33), // "on_pushButton_Livermorium_cli..."
QT_MOC_LITERAL(119, 3589, 32), // "on_pushButton_Tennessine_clicked"
QT_MOC_LITERAL(120, 3622, 31) // "on_pushButton_Oganesson_clicked"

    },
    "MainWindow\0sendName\0\0"
    "on_pushButton_Hydrogen_clicked\0"
    "on_pushButton_Helium_clicked\0"
    "on_pushButton_Lithium_clicked\0"
    "on_pushButton_Berylium_clicked\0"
    "on_pushButton_Boron_clicked\0"
    "on_pushButton_Carbon_clicked\0"
    "on_pushButton_Nitrogen_clicked\0"
    "on_pushButton_Oxygen_clicked\0"
    "on_pushButton_Fluorine_clicked\0"
    "on_pushButton_Neon_clicked\0"
    "on_pushButton_Sodium_clicked\0"
    "on_pushButton_Magnesium_clicked\0"
    "on_pushButton_Al_13_clicked\0"
    "on_pushButton_Silicon_clicked\0"
    "on_pushButton_Phosphorus_clicked\0"
    "on_pushButton_Sulphur_clicked\0"
    "on_pushButton_Chlorine_clicked\0"
    "on_pushButton_Argon_clicked\0"
    "on_pushButton_Potassium_clicked\0"
    "on_pushButton_Calcium_clicked\0"
    "on_pushButton_Scandium_clicked\0"
    "on_pushButton_Titanium_clicked\0"
    "on_pushButton_Vanadium_clicked\0"
    "on_pushButton_Magenesse_clicked\0"
    "on_pushButton_Iron_clicked\0"
    "on_pushButton_Cobalt_clicked\0"
    "on_pushButton_Nickel_clicked\0"
    "on_pushButton_Copper_clicked\0"
    "on_pushButton_Zinc_clicked\0"
    "on_pushButton_Gallium_clicked\0"
    "on_pushButton_Germanium_clicked\0"
    "on_pushButton_Arsenic_clicked\0"
    "on_pushButton_Selenium_clicked\0"
    "on_pushButton_Chromium_clicked\0"
    "on_pushButton_Bromine_clicked\0"
    "on_pushButton_Krypton_clicked\0"
    "on_pushButton_Rubidium_clicked\0"
    "on_pushButton_Strontium_clicked\0"
    "on_pushButton_Yittium_clicked\0"
    "on_pushButton_Zicronium_clicked\0"
    "on_pushButton_Niobium_clicked\0"
    "on_pushButton_Molybdenum_clicked\0"
    "on_pushButton_Technetium_clicked\0"
    "on_pushButton_Ruthenium_clicked\0"
    "on_pushButton_Rhodium_clicked\0"
    "on_pushButton_Palladium_clicked\0"
    "on_pushButton_Silver_clicked\0"
    "on_pushButton_Cadmium_clicked\0"
    "on_pushButton_Indium_clicked\0"
    "on_pushButton_Tin_clicked\0"
    "on_pushButton_Antimony_clicked\0"
    "on_pushButton_Tellurium_clicked\0"
    "on_pushButton_Iodine_clicked\0"
    "on_pushButton_Xenon_clicked\0"
    "on_pushButton_Caesium_clicked\0"
    "on_pushButton_Barium_clicked\0"
    "on_pushButton_Lanthanum_clicked\0"
    "on_pushButton_Cerium_clicked\0"
    "on_pushButton_Praseodymium_clicked\0"
    "on_pushButton_Neodymium_clicked\0"
    "on_pushButton_Promethium_clicked\0"
    "on_pushButton_Samarium_clicked\0"
    "on_pushButton_Europium_clicked\0"
    "on_pushButton_Gadolinium_clicked\0"
    "on_pushButton_Terbium_clicked\0"
    "on_pushButton_Dysprosium_clicked\0"
    "on_pushButton_Holmium_clicked\0"
    "on_pushButton_Erbium_clicked\0"
    "on_pushButton_Thulium_clicked\0"
    "on_pushButton_Ytterbium_clicked\0"
    "on_pushButton_Lutetium_clicked\0"
    "on_pushButton_Actinium_clicked\0"
    "on_pushButton_Hafnium_clicked\0"
    "on_pushButton_Tantalum_clicked\0"
    "on_pushButton_Tungsten_clicked\0"
    "on_pushButton_Rhenium_clicked\0"
    "on_pushButton_Osmium_clicked\0"
    "on_pushButton_Iridium_clicked\0"
    "on_pushButton_platinum_clicked\0"
    "on_pushButton_Gold_clicked\0"
    "on_pushButton_Mercury_clicked\0"
    "on_pushButton_Thallium_clicked\0"
    "on_pushButton_Lead_clicked\0"
    "on_pushButton_Bismuth_clicked\0"
    "on_pushButton_Polonium_clicked\0"
    "on_pushButton_Astatine_clicked\0"
    "on_pushButton_Radon_clicked\0"
    "on_pushButton_Francium_clicked\0"
    "on_pushButton_Radium_clicked\0"
    "on_pushButton_Thorium_clicked\0"
    "on_pushButton_Protactinium_clicked\0"
    "on_pushButton_Uranium_clicked\0"
    "on_pushButton_Neptunium_clicked\0"
    "on_pushButton_Plutonium_clicked\0"
    "on_pushButton_Americium_clicked\0"
    "on_pushButton_Curium_clicked\0"
    "on_pushButton_Berkelium_clicked\0"
    "on_pushButton_Californium_clicked\0"
    "on_pushButton_Einsteinium_clicked\0"
    "on_pushButton_Fermium_clicked\0"
    "on_pushButton_Mendevlevium_clicked\0"
    "on_pushButton_Nobelium_clicked\0"
    "on_pushButton_Lawrencium_clicked\0"
    "on_pushButton_Rutherfordium_clicked\0"
    "on_pushButton_Dubnium_clicked\0"
    "on_pushButton_Seaborgium_clicked\0"
    "on_pushButton_Bohrium_clicked\0"
    "on_pushButton_hassium_clicked\0"
    "on_pushButton_Meitnerium_clicked\0"
    "on_pushButton_Darmstadium_clicked\0"
    "on_pushButton_Roentgenium_clicked\0"
    "on_pushButton_Coprenicium_clicked\0"
    "on_pushButton_Nihomium_clicked\0"
    "on_pushButton_Flerovium_clicked\0"
    "on_pushButton_Moscovium_clicked\0"
    "on_pushButton_Livermorium_clicked\0"
    "on_pushButton_Tennessine_clicked\0"
    "on_pushButton_Oganesson_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
     119,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  609,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,  612,    2, 0x08 /* Private */,
       4,    0,  613,    2, 0x08 /* Private */,
       5,    0,  614,    2, 0x08 /* Private */,
       6,    0,  615,    2, 0x08 /* Private */,
       7,    0,  616,    2, 0x08 /* Private */,
       8,    0,  617,    2, 0x08 /* Private */,
       9,    0,  618,    2, 0x08 /* Private */,
      10,    0,  619,    2, 0x08 /* Private */,
      11,    0,  620,    2, 0x08 /* Private */,
      12,    0,  621,    2, 0x08 /* Private */,
      13,    0,  622,    2, 0x08 /* Private */,
      14,    0,  623,    2, 0x08 /* Private */,
      15,    0,  624,    2, 0x08 /* Private */,
      16,    0,  625,    2, 0x08 /* Private */,
      17,    0,  626,    2, 0x08 /* Private */,
      18,    0,  627,    2, 0x08 /* Private */,
      19,    0,  628,    2, 0x08 /* Private */,
      20,    0,  629,    2, 0x08 /* Private */,
      21,    0,  630,    2, 0x08 /* Private */,
      22,    0,  631,    2, 0x08 /* Private */,
      23,    0,  632,    2, 0x08 /* Private */,
      24,    0,  633,    2, 0x08 /* Private */,
      25,    0,  634,    2, 0x08 /* Private */,
      26,    0,  635,    2, 0x08 /* Private */,
      27,    0,  636,    2, 0x08 /* Private */,
      28,    0,  637,    2, 0x08 /* Private */,
      29,    0,  638,    2, 0x08 /* Private */,
      30,    0,  639,    2, 0x08 /* Private */,
      31,    0,  640,    2, 0x08 /* Private */,
      32,    0,  641,    2, 0x08 /* Private */,
      33,    0,  642,    2, 0x08 /* Private */,
      34,    0,  643,    2, 0x08 /* Private */,
      35,    0,  644,    2, 0x08 /* Private */,
      36,    0,  645,    2, 0x08 /* Private */,
      37,    0,  646,    2, 0x08 /* Private */,
      38,    0,  647,    2, 0x08 /* Private */,
      39,    0,  648,    2, 0x08 /* Private */,
      40,    0,  649,    2, 0x08 /* Private */,
      41,    0,  650,    2, 0x08 /* Private */,
      42,    0,  651,    2, 0x08 /* Private */,
      43,    0,  652,    2, 0x08 /* Private */,
      44,    0,  653,    2, 0x08 /* Private */,
      45,    0,  654,    2, 0x08 /* Private */,
      46,    0,  655,    2, 0x08 /* Private */,
      47,    0,  656,    2, 0x08 /* Private */,
      48,    0,  657,    2, 0x08 /* Private */,
      49,    0,  658,    2, 0x08 /* Private */,
      50,    0,  659,    2, 0x08 /* Private */,
      51,    0,  660,    2, 0x08 /* Private */,
      52,    0,  661,    2, 0x08 /* Private */,
      53,    0,  662,    2, 0x08 /* Private */,
      54,    0,  663,    2, 0x08 /* Private */,
      55,    0,  664,    2, 0x08 /* Private */,
      56,    0,  665,    2, 0x08 /* Private */,
      57,    0,  666,    2, 0x08 /* Private */,
      58,    0,  667,    2, 0x08 /* Private */,
      59,    0,  668,    2, 0x08 /* Private */,
      60,    0,  669,    2, 0x08 /* Private */,
      61,    0,  670,    2, 0x08 /* Private */,
      62,    0,  671,    2, 0x08 /* Private */,
      63,    0,  672,    2, 0x08 /* Private */,
      64,    0,  673,    2, 0x08 /* Private */,
      65,    0,  674,    2, 0x08 /* Private */,
      66,    0,  675,    2, 0x08 /* Private */,
      67,    0,  676,    2, 0x08 /* Private */,
      68,    0,  677,    2, 0x08 /* Private */,
      69,    0,  678,    2, 0x08 /* Private */,
      70,    0,  679,    2, 0x08 /* Private */,
      71,    0,  680,    2, 0x08 /* Private */,
      72,    0,  681,    2, 0x08 /* Private */,
      73,    0,  682,    2, 0x08 /* Private */,
      74,    0,  683,    2, 0x08 /* Private */,
      75,    0,  684,    2, 0x08 /* Private */,
      76,    0,  685,    2, 0x08 /* Private */,
      77,    0,  686,    2, 0x08 /* Private */,
      78,    0,  687,    2, 0x08 /* Private */,
      79,    0,  688,    2, 0x08 /* Private */,
      80,    0,  689,    2, 0x08 /* Private */,
      81,    0,  690,    2, 0x08 /* Private */,
      82,    0,  691,    2, 0x08 /* Private */,
      83,    0,  692,    2, 0x08 /* Private */,
      84,    0,  693,    2, 0x08 /* Private */,
      85,    0,  694,    2, 0x08 /* Private */,
      86,    0,  695,    2, 0x08 /* Private */,
      87,    0,  696,    2, 0x08 /* Private */,
      88,    0,  697,    2, 0x08 /* Private */,
      89,    0,  698,    2, 0x08 /* Private */,
      90,    0,  699,    2, 0x08 /* Private */,
      91,    0,  700,    2, 0x08 /* Private */,
      92,    0,  701,    2, 0x08 /* Private */,
      93,    0,  702,    2, 0x08 /* Private */,
      94,    0,  703,    2, 0x08 /* Private */,
      95,    0,  704,    2, 0x08 /* Private */,
      96,    0,  705,    2, 0x08 /* Private */,
      97,    0,  706,    2, 0x08 /* Private */,
      98,    0,  707,    2, 0x08 /* Private */,
      99,    0,  708,    2, 0x08 /* Private */,
     100,    0,  709,    2, 0x08 /* Private */,
     101,    0,  710,    2, 0x08 /* Private */,
     102,    0,  711,    2, 0x08 /* Private */,
     103,    0,  712,    2, 0x08 /* Private */,
     104,    0,  713,    2, 0x08 /* Private */,
     105,    0,  714,    2, 0x08 /* Private */,
     106,    0,  715,    2, 0x08 /* Private */,
     107,    0,  716,    2, 0x08 /* Private */,
     108,    0,  717,    2, 0x08 /* Private */,
     109,    0,  718,    2, 0x08 /* Private */,
     110,    0,  719,    2, 0x08 /* Private */,
     111,    0,  720,    2, 0x08 /* Private */,
     112,    0,  721,    2, 0x08 /* Private */,
     113,    0,  722,    2, 0x08 /* Private */,
     114,    0,  723,    2, 0x08 /* Private */,
     115,    0,  724,    2, 0x08 /* Private */,
     116,    0,  725,    2, 0x08 /* Private */,
     117,    0,  726,    2, 0x08 /* Private */,
     118,    0,  727,    2, 0x08 /* Private */,
     119,    0,  728,    2, 0x08 /* Private */,
     120,    0,  729,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sendName((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->on_pushButton_Hydrogen_clicked(); break;
        case 2: _t->on_pushButton_Helium_clicked(); break;
        case 3: _t->on_pushButton_Lithium_clicked(); break;
        case 4: _t->on_pushButton_Berylium_clicked(); break;
        case 5: _t->on_pushButton_Boron_clicked(); break;
        case 6: _t->on_pushButton_Carbon_clicked(); break;
        case 7: _t->on_pushButton_Nitrogen_clicked(); break;
        case 8: _t->on_pushButton_Oxygen_clicked(); break;
        case 9: _t->on_pushButton_Fluorine_clicked(); break;
        case 10: _t->on_pushButton_Neon_clicked(); break;
        case 11: _t->on_pushButton_Sodium_clicked(); break;
        case 12: _t->on_pushButton_Magnesium_clicked(); break;
        case 13: _t->on_pushButton_Al_13_clicked(); break;
        case 14: _t->on_pushButton_Silicon_clicked(); break;
        case 15: _t->on_pushButton_Phosphorus_clicked(); break;
        case 16: _t->on_pushButton_Sulphur_clicked(); break;
        case 17: _t->on_pushButton_Chlorine_clicked(); break;
        case 18: _t->on_pushButton_Argon_clicked(); break;
        case 19: _t->on_pushButton_Potassium_clicked(); break;
        case 20: _t->on_pushButton_Calcium_clicked(); break;
        case 21: _t->on_pushButton_Scandium_clicked(); break;
        case 22: _t->on_pushButton_Titanium_clicked(); break;
        case 23: _t->on_pushButton_Vanadium_clicked(); break;
        case 24: _t->on_pushButton_Magenesse_clicked(); break;
        case 25: _t->on_pushButton_Iron_clicked(); break;
        case 26: _t->on_pushButton_Cobalt_clicked(); break;
        case 27: _t->on_pushButton_Nickel_clicked(); break;
        case 28: _t->on_pushButton_Copper_clicked(); break;
        case 29: _t->on_pushButton_Zinc_clicked(); break;
        case 30: _t->on_pushButton_Gallium_clicked(); break;
        case 31: _t->on_pushButton_Germanium_clicked(); break;
        case 32: _t->on_pushButton_Arsenic_clicked(); break;
        case 33: _t->on_pushButton_Selenium_clicked(); break;
        case 34: _t->on_pushButton_Chromium_clicked(); break;
        case 35: _t->on_pushButton_Bromine_clicked(); break;
        case 36: _t->on_pushButton_Krypton_clicked(); break;
        case 37: _t->on_pushButton_Rubidium_clicked(); break;
        case 38: _t->on_pushButton_Strontium_clicked(); break;
        case 39: _t->on_pushButton_Yittium_clicked(); break;
        case 40: _t->on_pushButton_Zicronium_clicked(); break;
        case 41: _t->on_pushButton_Niobium_clicked(); break;
        case 42: _t->on_pushButton_Molybdenum_clicked(); break;
        case 43: _t->on_pushButton_Technetium_clicked(); break;
        case 44: _t->on_pushButton_Ruthenium_clicked(); break;
        case 45: _t->on_pushButton_Rhodium_clicked(); break;
        case 46: _t->on_pushButton_Palladium_clicked(); break;
        case 47: _t->on_pushButton_Silver_clicked(); break;
        case 48: _t->on_pushButton_Cadmium_clicked(); break;
        case 49: _t->on_pushButton_Indium_clicked(); break;
        case 50: _t->on_pushButton_Tin_clicked(); break;
        case 51: _t->on_pushButton_Antimony_clicked(); break;
        case 52: _t->on_pushButton_Tellurium_clicked(); break;
        case 53: _t->on_pushButton_Iodine_clicked(); break;
        case 54: _t->on_pushButton_Xenon_clicked(); break;
        case 55: _t->on_pushButton_Caesium_clicked(); break;
        case 56: _t->on_pushButton_Barium_clicked(); break;
        case 57: _t->on_pushButton_Lanthanum_clicked(); break;
        case 58: _t->on_pushButton_Cerium_clicked(); break;
        case 59: _t->on_pushButton_Praseodymium_clicked(); break;
        case 60: _t->on_pushButton_Neodymium_clicked(); break;
        case 61: _t->on_pushButton_Promethium_clicked(); break;
        case 62: _t->on_pushButton_Samarium_clicked(); break;
        case 63: _t->on_pushButton_Europium_clicked(); break;
        case 64: _t->on_pushButton_Gadolinium_clicked(); break;
        case 65: _t->on_pushButton_Terbium_clicked(); break;
        case 66: _t->on_pushButton_Dysprosium_clicked(); break;
        case 67: _t->on_pushButton_Holmium_clicked(); break;
        case 68: _t->on_pushButton_Erbium_clicked(); break;
        case 69: _t->on_pushButton_Thulium_clicked(); break;
        case 70: _t->on_pushButton_Ytterbium_clicked(); break;
        case 71: _t->on_pushButton_Lutetium_clicked(); break;
        case 72: _t->on_pushButton_Actinium_clicked(); break;
        case 73: _t->on_pushButton_Hafnium_clicked(); break;
        case 74: _t->on_pushButton_Tantalum_clicked(); break;
        case 75: _t->on_pushButton_Tungsten_clicked(); break;
        case 76: _t->on_pushButton_Rhenium_clicked(); break;
        case 77: _t->on_pushButton_Osmium_clicked(); break;
        case 78: _t->on_pushButton_Iridium_clicked(); break;
        case 79: _t->on_pushButton_platinum_clicked(); break;
        case 80: _t->on_pushButton_Gold_clicked(); break;
        case 81: _t->on_pushButton_Mercury_clicked(); break;
        case 82: _t->on_pushButton_Thallium_clicked(); break;
        case 83: _t->on_pushButton_Lead_clicked(); break;
        case 84: _t->on_pushButton_Bismuth_clicked(); break;
        case 85: _t->on_pushButton_Polonium_clicked(); break;
        case 86: _t->on_pushButton_Astatine_clicked(); break;
        case 87: _t->on_pushButton_Radon_clicked(); break;
        case 88: _t->on_pushButton_Francium_clicked(); break;
        case 89: _t->on_pushButton_Radium_clicked(); break;
        case 90: _t->on_pushButton_Thorium_clicked(); break;
        case 91: _t->on_pushButton_Protactinium_clicked(); break;
        case 92: _t->on_pushButton_Uranium_clicked(); break;
        case 93: _t->on_pushButton_Neptunium_clicked(); break;
        case 94: _t->on_pushButton_Plutonium_clicked(); break;
        case 95: _t->on_pushButton_Americium_clicked(); break;
        case 96: _t->on_pushButton_Curium_clicked(); break;
        case 97: _t->on_pushButton_Berkelium_clicked(); break;
        case 98: _t->on_pushButton_Californium_clicked(); break;
        case 99: _t->on_pushButton_Einsteinium_clicked(); break;
        case 100: _t->on_pushButton_Fermium_clicked(); break;
        case 101: _t->on_pushButton_Mendevlevium_clicked(); break;
        case 102: _t->on_pushButton_Nobelium_clicked(); break;
        case 103: _t->on_pushButton_Lawrencium_clicked(); break;
        case 104: _t->on_pushButton_Rutherfordium_clicked(); break;
        case 105: _t->on_pushButton_Dubnium_clicked(); break;
        case 106: _t->on_pushButton_Seaborgium_clicked(); break;
        case 107: _t->on_pushButton_Bohrium_clicked(); break;
        case 108: _t->on_pushButton_hassium_clicked(); break;
        case 109: _t->on_pushButton_Meitnerium_clicked(); break;
        case 110: _t->on_pushButton_Darmstadium_clicked(); break;
        case 111: _t->on_pushButton_Roentgenium_clicked(); break;
        case 112: _t->on_pushButton_Coprenicium_clicked(); break;
        case 113: _t->on_pushButton_Nihomium_clicked(); break;
        case 114: _t->on_pushButton_Flerovium_clicked(); break;
        case 115: _t->on_pushButton_Moscovium_clicked(); break;
        case 116: _t->on_pushButton_Livermorium_clicked(); break;
        case 117: _t->on_pushButton_Tennessine_clicked(); break;
        case 118: _t->on_pushButton_Oganesson_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MainWindow::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::sendName)) {
                *result = 0;
            }
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 119)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 119;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 119)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 119;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::sendName(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
