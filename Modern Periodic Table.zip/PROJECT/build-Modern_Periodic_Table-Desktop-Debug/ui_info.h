/********************************************************************************
** Form generated from reading UI file 'info.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INFO_H
#define UI_INFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Info
{
public:
    QPushButton *closeButton;
    QGroupBox *groupBox_3;
    QLabel *lbl_facts;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_5;
    QLabel *lbl_pic;
    QLabel *lbl_shell;
    QLabel *lbl_prop;
    QGroupBox *groupBox;
    QWidget *layoutWidget_2;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QWidget *layoutWidget_3;
    QVBoxLayout *verticalLayout_2;
    QLabel *lbl_name;
    QLabel *lbl_atNumber;
    QLabel *lbl_Symbol;
    QLabel *lbl_Weight;
    QWidget *layoutWidget_4;
    QHBoxLayout *horizontalLayout;
    QLabel *label_5;
    QLabel *lbl_ec;
    QWidget *layoutWidget_5;
    QVBoxLayout *verticalLayout_6;
    QGroupBox *groupBox_2;
    QLabel *lbl_isotopes;
    QLabel *lbl_isotopes2;
    QLabel *lbl_trunk;

    void setupUi(QDialog *Info)
    {
        if (Info->objectName().isEmpty())
            Info->setObjectName(QStringLiteral("Info"));
        Info->resize(1016, 716);
        closeButton = new QPushButton(Info);
        closeButton->setObjectName(QStringLiteral("closeButton"));
        closeButton->setGeometry(QRect(30, 650, 75, 23));
        groupBox_3 = new QGroupBox(Info);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(30, 360, 481, 261));
        lbl_facts = new QLabel(groupBox_3);
        lbl_facts->setObjectName(QStringLiteral("lbl_facts"));
        lbl_facts->setGeometry(QRect(10, 30, 321, 111));
        lbl_facts->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        lbl_facts->setWordWrap(true);
        layoutWidget = new QWidget(groupBox_3);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(360, 30, 111, 110));
        verticalLayout_5 = new QVBoxLayout(layoutWidget);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        lbl_pic = new QLabel(layoutWidget);
        lbl_pic->setObjectName(QStringLiteral("lbl_pic"));
        lbl_pic->setMinimumSize(QSize(85, 85));
        lbl_pic->setMaximumSize(QSize(85, 85));
        lbl_pic->setScaledContents(true);
        lbl_pic->setAlignment(Qt::AlignCenter);

        verticalLayout_5->addWidget(lbl_pic);

        lbl_shell = new QLabel(groupBox_3);
        lbl_shell->setObjectName(QStringLiteral("lbl_shell"));
        lbl_shell->setGeometry(QRect(350, 96, 110, 108));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        lbl_shell->setFont(font);
        lbl_shell->setAlignment(Qt::AlignCenter);
        lbl_prop = new QLabel(Info);
        lbl_prop->setObjectName(QStringLiteral("lbl_prop"));
        lbl_prop->setGeometry(QRect(569, 10, 421, 661));
        lbl_prop->setFont(font);
        lbl_prop->setAlignment(Qt::AlignCenter);
        groupBox = new QGroupBox(Info);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(30, 10, 341, 171));
        layoutWidget_2 = new QWidget(groupBox);
        layoutWidget_2->setObjectName(QStringLiteral("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(0, 30, 118, 111));
        verticalLayout = new QVBoxLayout(layoutWidget_2);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget_2);
        label->setObjectName(QStringLiteral("label"));
        label->setFont(font);

        verticalLayout->addWidget(label);

        label_2 = new QLabel(layoutWidget_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        verticalLayout->addWidget(label_2);

        label_3 = new QLabel(layoutWidget_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout->addWidget(label_3);

        label_4 = new QLabel(layoutWidget_2);
        label_4->setObjectName(QStringLiteral("label_4"));

        verticalLayout->addWidget(label_4);

        layoutWidget_3 = new QWidget(groupBox);
        layoutWidget_3->setObjectName(QStringLiteral("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(100, 30, 131, 111));
        verticalLayout_2 = new QVBoxLayout(layoutWidget_3);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        lbl_name = new QLabel(layoutWidget_3);
        lbl_name->setObjectName(QStringLiteral("lbl_name"));
        QFont font1;
        font1.setStyleStrategy(QFont::PreferDefault);
        lbl_name->setFont(font1);

        verticalLayout_2->addWidget(lbl_name);

        lbl_atNumber = new QLabel(layoutWidget_3);
        lbl_atNumber->setObjectName(QStringLiteral("lbl_atNumber"));

        verticalLayout_2->addWidget(lbl_atNumber);

        lbl_Symbol = new QLabel(layoutWidget_3);
        lbl_Symbol->setObjectName(QStringLiteral("lbl_Symbol"));

        verticalLayout_2->addWidget(lbl_Symbol);

        lbl_Weight = new QLabel(layoutWidget_3);
        lbl_Weight->setObjectName(QStringLiteral("lbl_Weight"));

        verticalLayout_2->addWidget(lbl_Weight);

        layoutWidget_4 = new QWidget(groupBox);
        layoutWidget_4->setObjectName(QStringLiteral("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(0, 150, 271, 19));
        horizontalLayout = new QHBoxLayout(layoutWidget_4);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget_4);
        label_5->setObjectName(QStringLiteral("label_5"));

        horizontalLayout->addWidget(label_5);

        lbl_ec = new QLabel(layoutWidget_4);
        lbl_ec->setObjectName(QStringLiteral("lbl_ec"));

        horizontalLayout->addWidget(lbl_ec);

        layoutWidget_5 = new QWidget(Info);
        layoutWidget_5->setObjectName(QStringLiteral("layoutWidget_5"));
        layoutWidget_5->setGeometry(QRect(590, 0, 411, 691));
        verticalLayout_6 = new QVBoxLayout(layoutWidget_5);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        groupBox_2 = new QGroupBox(Info);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(60, 200, 511, 171));
        groupBox_2->setFlat(false);
        lbl_isotopes = new QLabel(groupBox_2);
        lbl_isotopes->setObjectName(QStringLiteral("lbl_isotopes"));
        lbl_isotopes->setGeometry(QRect(10, 30, 201, 111));
        lbl_isotopes->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        lbl_isotopes2 = new QLabel(groupBox_2);
        lbl_isotopes2->setObjectName(QStringLiteral("lbl_isotopes2"));
        lbl_isotopes2->setGeometry(QRect(270, 30, 241, 111));
        lbl_isotopes2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        lbl_trunk = new QLabel(groupBox_2);
        lbl_trunk->setObjectName(QStringLiteral("lbl_trunk"));
        lbl_trunk->setGeometry(QRect(-10, 140, 391, 20));
        QFont font2;
        font2.setBold(false);
        font2.setWeight(50);
        lbl_trunk->setFont(font2);
        lbl_trunk->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        lbl_trunk->setAlignment(Qt::AlignCenter);

        retranslateUi(Info);

        QMetaObject::connectSlotsByName(Info);
    } // setupUi

    void retranslateUi(QDialog *Info)
    {
        Info->setWindowTitle(QApplication::translate("Info", "Dialog", 0));
        closeButton->setText(QApplication::translate("Info", "Close", 0));
        groupBox_3->setTitle(QApplication::translate("Info", "Some facts-", 0));
        lbl_facts->setText(QApplication::translate("Info", "-- None --", 0));
        lbl_shell->setText(QApplication::translate("Info", "Electron Shell", 0));
        lbl_prop->setText(QApplication::translate("Info", "Properties-", 0));
        groupBox->setTitle(QApplication::translate("Info", "Properties-", 0));
        label->setText(QApplication::translate("Info", "Element Name:", 0));
        label_2->setText(QApplication::translate("Info", "<html><head/><body><p><span style=\" font-weight:600;\">Atomic Number:</span></p></body></html>", 0));
        label_3->setText(QApplication::translate("Info", "<html><head/><body><p><span style=\" font-weight:600;\">Atomic Symbol:</span></p></body></html>", 0));
        label_4->setText(QApplication::translate("Info", "<html><head/><body><p><span style=\" font-weight:600;\">Atomic Weight:</span></p></body></html>", 0));
        lbl_name->setText(QApplication::translate("Info", "--", 0));
        lbl_atNumber->setText(QApplication::translate("Info", "--", 0));
        lbl_Symbol->setText(QApplication::translate("Info", "--", 0));
        lbl_Weight->setText(QApplication::translate("Info", "--", 0));
        label_5->setText(QApplication::translate("Info", "<html><head/><body><p><span style=\" font-weight:600;\">Electronic Configuration: </span></p></body></html>", 0));
        lbl_ec->setText(QApplication::translate("Info", "--", 0));
        groupBox_2->setTitle(QApplication::translate("Info", "Isotopes", 0));
        lbl_isotopes->setText(QApplication::translate("Info", "-- None --", 0));
        lbl_trunk->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Info: public Ui_Info {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INFO_H
